﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Test_Accionlabs
{
    class WaitForloadingTheElement
    {
        public static object TimeUnit { get; private set; }

        [Obsolete]
        public static void WaitForElementLoad(By by, int timeoutInSeconds = 60)
        {
            if (timeoutInSeconds > 0)
            {
                WebDriverWait wait = new WebDriverWait(Properties.driver, TimeSpan.FromSeconds(timeoutInSeconds));
                wait.Until(ExpectedConditions.ElementIsVisible(by));
            }
        }

        public static void WaitImplicit()
        {
           //Properties.driver.Manage().Timeouts().ImplicitWait(TimeSpan.FromSeconds,45);
        }
    }
}
