﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Appium.Android;

namespace Test_Accionlabs.Test
{
    [TestFixture(typeof(ChromeDriver))]
    [TestFixture(typeof(FirefoxDriver))]
    //[TestFixture(typeof(AndroidDriver<>))]
    class AccessLSACPage<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        //to set up the browser
        [SetUp]
        public void Init()
        {
            SetUPTearDown.Initialize<TWebDriver>();
        }

        //to close the browser
        [TearDown]
        public void Tear()
        {
            SetUPTearDown.TeardownTest();
        }

        [Test]
        [Obsolete]
        public void LSACPage()
        {
            //access to homepage and checking all practical test link
            HomePagePOM HP = new HomePagePOM();
            HP.HomePage();
        }

        [Test]
        [Obsolete]
        public void TutorialPage()
        {
            //access to tutorial and checking the all video link
            TutorialPagePOM TP = new TutorialPagePOM();
            TP.TutorialPage();
        }
    }
}
