﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using NUnit.Framework;
using System.Threading;

namespace Test_Accionlabs
{
    class HomePagePOM
    {
        [Obsolete]
        public HomePagePOM()
        {
            PageFactory.InitElements(Properties.driver, this);
        }

        //to find Tutorials link 
        [FindsBy(How = How.LinkText, Using = "Tutorials")]
        public IWebElement linkTutorials { get; set; }

        //to find The Official LSAT PrepTest 71 link
        [FindsBy(How = How.CssSelector, Using = ".list-group [class='list-group-item bb-wid-2 bb-wid-lc-1']:nth-of-type(1) #practiceTestLink")]
        public IWebElement practiceTestLink71 { get; set; }

        //to find The Official LSAT PrepTest 73 link
        [FindsBy(How = How.CssSelector, Using = ".list-group [class='list-group-item bb-wid-2 bb-wid-lc-1']:nth-of-type(2) #practiceTestLink")]
        public IWebElement practiceTestLink73 { get; set; }

        //to find The Official LSAT PrepTest 74 link
        [FindsBy(How = How.CssSelector, Using = ".list-group [class='list-group-item bb-wid-2 bb-wid-lc-1']:nth-of-type(3) #practiceTestLink")]
        public IWebElement practiceTestLink74 { get; set; }


        [Obsolete]
        public void  HomePage()
        {
            Properties.driver.Navigate().GoToUrl(ExcelLibrary.ReadData(1, "URL"));
            //WaitForloadingTheElement.WaitForElementLoad(By.LinkText("Help"));
            Properties.driver.Manage().Window.Maximize();
            //String Title1 = Properties.driver.FindElement(By.TagName("title")).Text;

           
           String HomeURL = Properties.driver.Url;
           // WaitForloadingTheElement.WaitForElementLoad(By.LinkText("Help"));
            Assert.AreEqual("LSAC Test Preparation", Properties.driver.Title);
            Thread.Sleep(5000);
            practiceTestLink71.Click();
            
            WaitForloadingTheElement.WaitForElementLoad(By.XPath("//*[@id='ApolloContainerInner']/div/div/div/div[2]/div[3]/div/button/div/span"));
            Assert.AreEqual("The Official LSAT PrepTest 71", Properties.driver.FindElement(By.LinkText("The Official LSAT PrepTest 71")).Text);
            Thread.Sleep(2000);
            Properties.driver.Navigate().Back();

            practiceTestLink73.Click();

            WaitForloadingTheElement.WaitForElementLoad(By.XPath("//*[@id='ApolloContainerInner']/div/div/div/div[2]/div[3]/div/button/div/span"));
            Assert.AreEqual("The Official LSAT PrepTest 73", Properties.driver.FindElement(By.LinkText("The Official LSAT PrepTest 73")).Text);
            Thread.Sleep(2000);
            Properties.driver.Navigate().Back();

            practiceTestLink74.Click();

            WaitForloadingTheElement.WaitForElementLoad(By.XPath("//*[@id='ApolloContainerInner']/div/div/div/div[2]/div[3]/div/button/div/span"));
            Assert.AreEqual("The Official LSAT PrepTest 74", Properties.driver.FindElement(By.LinkText("The Official LSAT PrepTest 74")).Text);
            Thread.Sleep(2000);
            Properties.driver.Navigate().Back();

            Thread.Sleep(5000);
            linkTutorials.Click();
            Assert.AreEqual("https://familiar.lsac.org/tutorials", Properties.driver.Url);
            
            //Thread.Sleep(10000);
            WaitForloadingTheElement.WaitForElementLoad(By.XPath("//*[@id='masterContentPane']/div/div/div[1]/h1/span"));
            Assert.AreEqual("Tutorials", Properties.driver.FindElement(By.XPath("//*[@id='masterContentPane']/div/div/div[1]/h1/span")).Text);

            Properties.driver.Navigate().Back();
            Assert.AreEqual(HomeURL, Properties.driver.Url);
        }


    }
}
