﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using NUnit.Framework;
using System.Threading;


namespace Test_Accionlabs
{
    class TutorialPagePOM
    {
        public TutorialPagePOM()
        {
            {
                PageFactory.InitElements(Properties.driver, this);
            }
        }

        //to find Tutorials link 
        [FindsBy(How = How.LinkText, Using = "Tutorials")]
        public IWebElement linkTutorials { get; set; }

        //to find Video link 1
        [FindsBy(How = How.CssSelector, Using = ".list-group .list-group-item:nth-of-type(1) #videoLink")]
        public IWebElement videoLink1 { get; set; }

        //to find Video link 2
        [FindsBy(How = How.CssSelector, Using = ".list-group .list-group-item:nth-of-type(2) #videoLink")]
        public IWebElement videoLink2 { get; set; }

        //to find Video link 3
        [FindsBy(How = How.CssSelector, Using = ".list-group .list-group-item:nth-of-type(3) #videoLink")]
        public IWebElement videoLink3 { get; set; }

        //to find Video link 4
        [FindsBy(How = How.CssSelector, Using = ".list-group .list-group-item:nth-of-type(4) #videoLink")]
        public IWebElement videoLink4 { get; set; }

        //to find Video link 5
        [FindsBy(How = How.CssSelector, Using = ".list-group .list-group-item:nth-of-type(5) #videoLink")]
        public IWebElement videoLink5 { get; set; }

        //to find Video link 6
        [FindsBy(How = How.CssSelector, Using = ".list-group .list-group-item:nth-of-type(6) #videoLink")]
        public IWebElement videoLink6 { get; set; }

        //to find play button for video
        [FindsBy(How = How.CssSelector, Using = "i#playButton")]
        public IWebElement playButton { get; set; }

        [Obsolete]
        public void TutorialPage()
        {
            Properties.driver.Navigate().GoToUrl(ExcelLibrary.ReadData(1, "URL"));
            Properties.driver.Manage().Window.Maximize();

            Thread.Sleep(5000);
            //navigate to tutorial page.
            linkTutorials.Click();
            Assert.AreEqual("https://familiar.lsac.org/tutorials", Properties.driver.Url);
            //var Tut = Properties.driver.FindElement(By.XPath("//*[@id='masterContentPane']/div/div/div[1]/h1/span"));

            //Verify each video link is clickable and video is play-stop
            
            WaitForloadingTheElement.WaitForElementLoad(By.XPath("//*[@id='masterContentPane']/div/div/div[1]/h1/span"));
            Assert.AreEqual("Tutorials", Properties.driver.FindElement(By.XPath("//*[@id='masterContentPane']/div/div/div[1]/h1/span")).Text);

            videoLink1.Click();
            WaitForloadingTheElement.WaitForElementLoad(By.CssSelector("i#playButton"));
            playButton.Click();//Click on play button
            Thread.Sleep(10000);
            playButton.Click();//Click on stop button
            Thread.Sleep(2000);
            Assert.AreEqual("Answering Test Questions (with Narration) - 9:17m", Properties.driver.FindElement(By.CssSelector(".disableLink")).Text);
            Thread.Sleep(2000);
            Properties.driver.Navigate().Back();

            Thread.Sleep(2000);
            videoLink2.Click();
            WaitForloadingTheElement.WaitForElementLoad(By.CssSelector("i#playButton"));
            playButton.Click();
            Thread.Sleep(10000);
            playButton.Click();
            Thread.Sleep(2000);
            Assert.AreEqual("Answering Test Questions (without Narration) - 3:08m", Properties.driver.FindElement(By.CssSelector(".disableLink")).Text);
            Thread.Sleep(2000);
            Properties.driver.Navigate().Back();

            Thread.Sleep(2000);
            videoLink3.Click();
            WaitForloadingTheElement.WaitForElementLoad(By.CssSelector("i#playButton"));
            playButton.Click();
            Thread.Sleep(10000);
            playButton.Click();
            Thread.Sleep(2000);
            Assert.AreEqual("Reading Comprehension Passages (with Narration) - 2:29m", Properties.driver.FindElement(By.CssSelector(".disableLink")).Text);
            Thread.Sleep(2000);
            Properties.driver.Navigate().Back();

            Thread.Sleep(2000);
            videoLink4.Click();
            WaitForloadingTheElement.WaitForElementLoad(By.CssSelector("i#playButton"));
            playButton.Click();
            Thread.Sleep(10000);
            playButton.Click();
            Thread.Sleep(2000);
            Assert.AreEqual("Reading Comprehension Passages (without Narration) - 0:40m", Properties.driver.FindElement(By.CssSelector(".disableLink")).Text);
            Thread.Sleep(2000);
            Properties.driver.Navigate().Back();

            Thread.Sleep(2000);
            videoLink5.Click();
            WaitForloadingTheElement.WaitForElementLoad(By.CssSelector("i#playButton"));
            playButton.Click();
            Thread.Sleep(10000);
            playButton.Click();
            Thread.Sleep(2000);
            Assert.AreEqual("Screen Preferences (with Narration) - 3:27m", Properties.driver.FindElement(By.CssSelector(".disableLink")).Text);
            Thread.Sleep(2000);
            Properties.driver.Navigate().Back();

            Thread.Sleep(2000);
            videoLink6.Click();
            WaitForloadingTheElement.WaitForElementLoad(By.CssSelector("i#playButton"));
            playButton.Click();
            Thread.Sleep(10000);
            playButton.Click();
            Thread.Sleep(2000);
            Assert.AreEqual("Screen Preferences (without Narration) - 1:16m", Properties.driver.FindElement(By.CssSelector(".disableLink")).Text);
            Thread.Sleep(2000);
            Properties.driver.Navigate().Back();
        }
    }
}
