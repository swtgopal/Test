﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace Test_Accionlabs
{
    class SetUPTearDown
    {
        //private static IWebDriver driver;

        public static IWebDriver Instance { get; set; }
        public static void Initialize<TWebDriver>() where TWebDriver : IWebDriver, new()
        {
            Properties.driver = new TWebDriver();
            ExcelLibrary.PopulateInCollection(@"C:\Test_Accionlabs\Data\TestData.xlsx");
            ExcelLibrary.ReadData(1, "URL");

        }

        public static void TeardownTest()
        {
            
            try
            {
                Properties.driver.Quit();
            }
            catch (Exception e)
            {
                Console.WriteLine("Browser is not able to closed due to Error-"+e);
                
            }

        }
    }
}
